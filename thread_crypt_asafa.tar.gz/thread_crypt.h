#ifndef _THREAD_CRYPT_H
# define _THREAD_CRYPT_H 1

# ifndef FALSE
#  define FALSE 0
# endif // FALSE
# ifndef TRUE
#  define TRUE 1
# endif // TRUE

# define SALT_CHARS "./ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz"

# define OPTIONS "i:o:hva:l:R:t:r:"

#endif // _THREAD_CRYPT_H
